# camcarpenter cdc-demo
Static website for testing Cookie x CPM consent via OneTrust
