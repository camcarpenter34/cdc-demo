document.cookie = "Perf_TestCookie" + "=" + "Test_CookieHere!";
